package com.example.calculator; // Kendi paket ismini yaz

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    EditText ekran;
    double sayi1 = 0;
    String islem = "";
    boolean yeniGiris = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Senin XML'indeki ID: editTextNumber
        ekran = findViewById(R.id.editTextNumber);

        // Sayı Butonları (Senin XML'indeki ID'lere göre)
        int[] sayiIds = {
                R.id.button20, // 0
                R.id.button15, // 1
                R.id.button16, // 2
                R.id.button17, // 3
                R.id.button10, // 4
                R.id.button12, // 5
                R.id.button13, // 6
                R.id.button6,  // 7
                R.id.button7,  // 8
                R.id.button8   // 9
        };

        for (int id : sayiIds) {
            findViewById(id).setOnClickListener(v -> {
                Button b = (Button) v;
                if (yeniGiris) {
                    ekran.setText("");
                    yeniGiris = false;
                }
                ekran.append(b.getText());
            });
        }

        // Virgül (button21)
        findViewById(R.id.button21).setOnClickListener(v -> ekran.append("."));

        // İşlem Butonları (Senin XML'indeki ID'lere göre)
        findViewById(R.id.button18).setOnClickListener(v -> islemSec("+")); // +
        findViewById(R.id.button14).setOnClickListener(v -> islemSec("-")); // -
        findViewById(R.id.button9).setOnClickListener(v -> islemSec("*"));  // x
        findViewById(R.id.button5).setOnClickListener(v -> islemSec("/"));  // /

        // AC Butonu (button3)
        findViewById(R.id.button3).setOnClickListener(v -> {
            ekran.setText("0");
            sayi1 = 0;
            yeniGiris = true;
        });

        // Eşittir Butonu (button22)
        findViewById(R.id.button22).setOnClickListener(v -> {
            if(ekran.getText().toString().isEmpty()) return;

            double sayi2 = Double.parseDouble(ekran.getText().toString());
            double sonuc = 0;

            switch (islem) {
                case "+": sonuc = sayi1 + sayi2; break;
                case "-": sonuc = sayi1 - sayi2; break;
                case "*": sonuc = sayi1 * sayi2; break;
                case "/":
                    if(sayi2 != 0) sonuc = sayi1 / sayi2;
                    else ekran.setText("Hata");
                    break;
            }

            ekran.setText(String.valueOf(sonuc));
            yeniGiris = true;
        });
    }

    private void islemSec(String s) {
        if(!ekran.getText().toString().isEmpty()) {
            sayi1 = Double.parseDouble(ekran.getText().toString());
            islem = s;
            yeniGiris = true;
        }
    }
}